﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Observer.Step1
{
    #region Strategy Pattern Stuff
    public interface IShootingBehaviour
    {
        void Shoot();
    }

    public class NormalShot : IShootingBehaviour
    {
        public void Shoot()
        {
            /* Shoot Logic */
        }
    }

    public class CantShoot : IShootingBehaviour
    {
        public void Shoot()
        {
            /* No Shoot Logic */
        }
    }

    public class ThrowKnifes : IShootingBehaviour
    {
        public void Shoot()
        {
            /* Throwing Logic */
        }
    }
    #endregion

    public abstract class GameUnit
    {
        private BattleMapDisplay _battleMapDisplay = new BattleMapDisplay();

        public Point Position { get; protected set; }
        public IShootingBehaviour ShootingBehaviour { get; protected set; }

        // Unit classes each take care of their own Display
        public abstract void Display();

        public void PerformShoot()
        {
            ShootingBehaviour.Shoot();
        }

        public void Move(Point newLocation)
        {
            Position = newLocation;
            _battleMapDisplay.Update(this);
        }
    }

    #region Units
    public class Soldier : GameUnit
    {
        public Soldier()
        {
            ShootingBehaviour = new NormalShot();
        }

        public override void Display()
        {
            /* Display code */
        }
    }

    public class Tank : GameUnit
    {
        public Tank()
        {
            ShootingBehaviour = new NormalShot();
        }

        public override void Display()
        {
            /* Display code */
        }
    }

    public class Engineer : GameUnit
    {
        public Engineer()
        {
            ShootingBehaviour = new CantShoot();
        }

        public override void Display()
        {
            /* Display code */
        }
    }

    public class Civilian : GameUnit
    {
        public Civilian()
        {
            ShootingBehaviour = new CantShoot();
        }

        public override void Display()
        {
            /* Display code */
        }
    }

    public class GangMember : GameUnit
    {
        public GangMember()
        {
            ShootingBehaviour = new ThrowKnifes();
        }

        public override void Display()
        {
            /* Display code */
        }
    }
    #endregion

    #region Screens
    public class BattleMapDisplay
    {
        public void Update(GameUnit unit)
        {
            /* Update the location of the unit on the map */
        }
    }
    #endregion
}
