﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Observer
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    #region Strategy Pattern Stuff
    public interface IShootingBehaviour
    {
        void Shoot();
    }

    public class NormalShot : IShootingBehaviour
    {
        public void Shoot()
        {
            /* Shoot Logic */
        }
    }

    public class CantShoot : IShootingBehaviour
    {
        public void Shoot()
        {
            /* No Shoot Logic */
        }
    }

    public class ThrowKnives : IShootingBehaviour
    {
        public void Shoot()
        {
            /* Throwing Logic */
        }
    }
    #endregion

    #region Observer Pattern Stuff
    public interface ISubject
    {
        void Subscribe(IObserver observer);
        void Unsubscribe(IObserver observer);
        void Notify();
    }

    public interface IObserver
    {
        void Update(ISubject subject);
    }
    #endregion

    public abstract class GameUnit : ISubject
    {
        private List<IObserver> Observers { get; set; }

        public Point Position { get; protected set; }
        public IShootingBehaviour ShootingBehaviour { get; protected set; }

        // Unit classes each take care of their own Display
        public abstract void Display();

        public GameUnit()
        {
            Observers = new List<IObserver>();
        }

        public void Subscribe(IObserver observer)
        {
            // Keep track of the observers
            if (!Observers.Contains(observer))
            {
                Observers.Add(observer);
            }
        }

        public void Unsubscribe(IObserver observer)
        {
            // Remove an observer from the list when it doesn't want to get notified anymore
            Observers.Remove(observer);
        }

        public void Notify()
        {
            foreach (IObserver observer in Observers)
            {
                observer.Update(this);
            }
        }

        public void PerformShoot()
        {
            ShootingBehaviour.Shoot();
        }

        public void Move(Point newLocation)
        {
            Position = newLocation;
            Notify();
        }
    }

    #region Units
    public class Soldier : GameUnit
    {
        public Soldier()
        {
            ShootingBehaviour = new NormalShot();
        }

        public override void Display()
        {
            /* Display code */
        }
    }

    public class Tank : GameUnit
    {
        public Tank()
        {
            ShootingBehaviour = new NormalShot();
        }

        public override void Display()
        {
            /* Display code */
        }
    }

    public class Engineer : GameUnit
    {
        public Engineer()
        {
            ShootingBehaviour = new CantShoot();
        }

        public override void Display()
        {
            /* Display code */
        }
    }

    public class Civilian : GameUnit
    {
        public Civilian()
        {
            ShootingBehaviour = new CantShoot();
        }

        public override void Display()
        {
            /* Display code */
        }
    }

    public class GangMember : GameUnit
    {
        public GangMember()
        {
            ShootingBehaviour = new ThrowKnives();
        }

        public override void Display()
        {
            /* Display code */
        }
    }
    #endregion

    #region Screens
    public class BattleMapDisplay : IObserver
    {
        public void Update(ISubject unit)
        {
            if (unit is GameUnit)
            {
                /* Update the location of the unit on the map */
                // ((GameUnit)unit).Position;
            }
        }
    }

    public class OverviewDisplay : IObserver
    {
        public void Update(ISubject unit)
        {
            if (unit is GameUnit)
            {
                /* Update the location of the unit on the map */
                // ((GameUnit)unit).Position;
            }
        }
    }
    #endregion
}